# Token Fucker by Asylum

![](https://img.shields.io/badge/Python-3.5--3.8-green)
![GitHub stars](https://img.shields.io/github/stars/asxlvm/DisparityTokenFucker)
[![Run on Repl.it](https://repl.it/badge/github/asxlvm/DisparityTokenFucker)](https://repl.it/github/asxlvm/DisparityTokenFucker)

#### Version: 2.0

> Example Video of v1.0: [here](https://youtu.be/zwCMeJSkuYc)

My Discord Server: [Join!](https://dsc.gg/asxlvm)
Slayer's Tool Server: [Join!](https://dsc.gg/externalnuker)

## How to Install

#### You need to have Python3 and pip installed just so you know

- 1. Download `tokenfucker.zip` in your device
- 2. Extract `tokenfucker.zip`
- 3. Run `pip install -r requirements.txt` in the directory you extracted `tokenfucker.zip` in the command line 
- 4. After you ran that command, you don't have to run it again because you have installed every dependency for the Token Fucker
- 5. To run the Token Fucker, type `python3 tokenfucker.py` in the directory you extracted `tokenfucker.zip` in through the command line
- 6. Enjoy, I guess

## Run on Replit

- 1. Press the Run on Replit button
- 2. Press Run

## Changelog

#### Version 1.0 (Aug 22, 2021)
- **Initial release**
- __Added:__
    - Removes/leaves every guild
    - Closes every DM and removes every friend
    - Changes bio, avatar and banner color
    - Changes client settings (language, theme etc.)

#### Version 1.1 (Aug 23, 2021)
- **Small update**
- __Added:__
    - Faster guild removing & leaving

#### Version 1.2 (Aug 23, 2021)
- **Medium update**
- __Added:__
    - Faster friend removing
    - Added blocking every user the account was in contact with
    - "Proper" ratelimit-handling
    - Support for running on Replit

#### Version 2.0
- **Big update**
- __Added:__
    - Actually closes DMs
    - Leaves every groupchat
    - Changed logging to basic prints for compatibility (removed one big dependency)
    - Adds icon to spam-created servers
    - Added a settings system so you can change the settings of the Token Fucker
