# Token Fucker by Asylum
#### Version: 1.0

> Example Video of v1.0: [here](https://youtu.be/zwCMeJSkuYc)

My Discord Server: [Join!](https://dsc.gg/asxlvm)
Slayer's Tool Server: [Join!](https://dsc.gg/externalnuker)

## How to Install

#### You need to have Python3 and pip installed just so you know

- 1. Download `tokenfucker.zip` in your device
- 2. Extract `tokenfucker.zip`
- 3. Run `pip install -r requirements.txt` in the directory you extracted `tokenfucker.zip` in the command line 
- 4. After you ran that command, you don't have to run it again because you have installed every dependency for the Token Fucker
- 5. To run the Token Fucker, type `python3 -O tokenfucker.pyc` in the directory you extracted `tokenfucker.zip` in through the command line
- 6. Enjoy, I guess
